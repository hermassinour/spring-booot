@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://www.iata.org/IATA/2015/00/2018.1/AirShoppingRQ", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.springboot.dto.airshoppingrq;
