package com.springboot.repository;

import com.springboot.model.AncillaryService;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AncillaryServiceRepository extends JpaRepository<AncillaryService, Long> {
}
