package com.springboot.service;

import com.springboot.model.Booking;
import com.springboot.model.Flight;
import com.springboot.model.User;
import com.springboot.repository.BookingRepository;
import com.springboot.repository.FlightRepository;
import com.springboot.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private FlightRepository flightRepository;

    // ✅ Method to book a flight
    public Booking createBooking(Long userId, Long flightId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Flight flight = flightRepository.findById(flightId)
                .orElseThrow(() -> new RuntimeException("Flight not found"));

        // Check if user already booked this flight
        boolean alreadyBooked = bookingRepository.findByUserId(userId)
                .stream()
                .anyMatch(booking -> booking.getFlight().getId().equals(flightId));

        if (alreadyBooked) {
            throw new RuntimeException("User already booked this flight");
        }

        // Create new booking
        Booking booking = new Booking(user, flight, "Pending", flight.getPrice());
        return bookingRepository.save(booking);
    }
}
