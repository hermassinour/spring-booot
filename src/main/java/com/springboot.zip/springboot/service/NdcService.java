package com.springboot.service;

import com.springboot.dto.airshoppingrq.AirShoppingRQ;
import com.springboot.dto.airshoppingrs.AirShoppingRS;
import com.springboot.dto.input.OfferPriceRequest;
import com.springboot.dto.offerpricers.OfferPriceRS;
import com.springboot.dto.output.AirShoppingResponse;
import com.springboot.dto.output.OfferPriceResponse;
import com.springboot.utils.DtoBuilder;
import com.springboot.utils.OfferPriceResponseMapper;
import com.springboot.utils.ResponseMapper;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.xml.transform.stream.StreamResult;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Collections;

@Service
public class NdcService {

    private final RestTemplate restTemplate;
    private final DtoBuilder dtoBuilder;

    @Value("${ndc.api.secret-key}")
    private String secretKey;

    @Value("${ndc.api.password}")
    private String password;

    @Value("${ndc.api.airshopping-url}")
    private String airShoppingUrl;

    @Value("${ndc.api.offerprice-url}")
    private String offerPriceUrl;

    public NdcService(RestTemplate restTemplate, DtoBuilder dtoBuilder) {
        this.restTemplate = restTemplate;
        this.dtoBuilder = dtoBuilder;
    }

    public AirShoppingResponse callNdcEndpoint(AirShoppingRQ airShoppingRQ) {
        String xmlRequest = marshalToXml(airShoppingRQ);
        HttpEntity<String> requestEntity = buildHttpEntity(xmlRequest);
        ResponseEntity<String> responseEntity = restTemplate.exchange(
                airShoppingUrl, HttpMethod.POST, requestEntity, String.class);

        if (responseEntity.getStatusCode().is2xxSuccessful() && responseEntity.getBody() != null) {
            AirShoppingRS rs = unmarshalXml(responseEntity.getBody(), AirShoppingRS.class);
            return ResponseMapper.mapToResponseDTO(rs);
        } else {
            throw new RuntimeException("AirShopping call failed: " + responseEntity.getStatusCode());
        }
    }

    public OfferPriceResponse handleOfferPrice(OfferPriceRequest input) {
        var rq = dtoBuilder.buildOfferPriceRQ(input);
        String xmlRequest = marshalToXml(rq);
        HttpEntity<String> requestEntity = buildHttpEntity(xmlRequest);
        ResponseEntity<String> responseEntity = restTemplate.exchange(
                offerPriceUrl, HttpMethod.POST, requestEntity, String.class);

        if (responseEntity.getStatusCode().is2xxSuccessful() && responseEntity.getBody() != null) {
            OfferPriceRS rs = unmarshalXml(responseEntity.getBody(), OfferPriceRS.class);
            return OfferPriceResponseMapper.mapToResponseDTO(rs);
        } else {
            throw new RuntimeException("OfferPrice call failed: " + responseEntity.getStatusCode());
        }
    }

    private HttpEntity<String> buildHttpEntity(String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_XML);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_XML));
        headers.set("SECRET-KEY", secretKey);
        headers.set("PASSWORD", password);
        return new HttpEntity<>(body, headers);
    }

    private String marshalToXml(Object obj) {
        try (StringWriter writer = new StringWriter()) {
            JAXBContext context = JAXBContext.newInstance(obj.getClass());
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            marshaller.marshal(obj, new StreamResult(writer));
            return writer.toString();
        } catch (Exception e) {
            throw new RuntimeException("Error marshalling object to XML", e);
        }
    }

    private <T> T unmarshalXml(String xml, Class<T> clazz) {
        try {
            JAXBContext context = JAXBContext.newInstance(clazz);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            return clazz.cast(unmarshaller.unmarshal(new StringReader(xml)));
        } catch (Exception e) {
            throw new RuntimeException("Error unmarshalling XML", e);
        }
    }
}
