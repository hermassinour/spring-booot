package com.springboot.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class FlightService {

    private static final Logger logger = LoggerFactory.getLogger(FlightService.class);

    @Autowired
    private RestTemplate restTemplate;

    // ✅ Correct API Endpoint
    private static final String AIRSHOPPING_URL = "https://ndc.worldsoftgroup.com/ndc/airshopping";

    // ✅ Headers (WorldSoft Requires These Instead of OAuth)
    private static final String SECRET_KEY = "WSNDCQR";
    private static final String PASSWORD = "NDCQatar_2025!$9yB#WS";

    // ✅ Generate XML Request Body (Fixed Multi-Line Formatting)
    private String buildAirShoppingRequest(String departure, String destination, String date) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<AirShoppingRQ xmlns=\"http://www.iata.org/IATA/2015/00/2018.1/AirShoppingRQ\">"
                + "    <PayloadAttributes>"
                + "        <Version>18.1</Version>"
                + "    </PayloadAttributes>"
                + "    <PointOfSale>"
                + "        <Country>"
                + "            <CountryCode>SA</CountryCode>"
                + "        </Country>"
                + "    </PointOfSale>"
                + "    <Party>"
                + "        <Participant>"
                + "            <Aggregator>"
                + "                <AggregatorID>SRA</AggregatorID>"
                + "            </Aggregator>"
                + "        </Participant>"
                + "        <Recipient>"
                + "            <ORA>"
                + "                <AirlineDesigCode>QR</AirlineDesigCode>"
                + "            </ORA>"
                + "        </Recipient>"
                + "        <Sender>"
                + "           <TravelAgency>"
                + "                <AgencyID>71221872</AgencyID>"
                + "                <IATA_Number>71221872</IATA_Number>"
                + "                <Name>AL ANAN TOURS</Name>"
                + "                <PseudoCityID>SRASA001</PseudoCityID>"
                + "                <TypeCode>TravelAgency</TypeCode>"
                + "            </TravelAgency>"
                + "        </Sender>"
                + "    </Party>"
                + "    <Request>"
                + "        <FlightRequest>"
                + "            <OriginDestRequest>"
                + "                <DestArrivalRequest>"
                + "                    <IATA_LocationCode>" + destination + "</IATA_LocationCode>"
                + "                </DestArrivalRequest>"
                + "                <OriginDepRequest>"
                + "                    <IATA_LocationCode>" + departure + "</IATA_LocationCode>"
                + "                    <Date>" + date + "</Date>"
                + "                </OriginDepRequest>"
                + "            </OriginDestRequest>"
                + "        </FlightRequest>"
                + "        <Paxs>"
                + "            <Pax>"
                + "                <PaxID>PAX1</PaxID>"
                + "                <PTC>ADT</PTC>"
                + "                <PaxRefID>PAX1</PaxRefID>"
                + "            </Pax>"
                + "        </Paxs>"
                + "        <ShoppingCriteria>"
                + "            <CabinTypeCriteria>"
                + "                <CabinTypeName>ECO</CabinTypeName>"
                + "            </CabinTypeCriteria>"
                + "        </ShoppingCriteria>"
                + "    </Request>"
                + "</AirShoppingRQ>";
    }

    // ✅ Search Flights via WorldSoft API
    public ResponseEntity<String> searchFlightsFromWorldSoft(String departure, String destination, String date) {
        try {
            // 📝 Build the XML request body
            String requestXml = buildAirShoppingRequest(departure, destination, date);

            // 📡 Set Headers
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_XML);
            headers.setAccept(List.of(MediaType.APPLICATION_XML));
            headers.set("SECRET-KEY", SECRET_KEY);
            headers.set("PASSWORD", PASSWORD);

            HttpEntity<String> entity = new HttpEntity<>(requestXml, headers);

            // 📝 Log request details
            logger.info("🔍 Sending AirShopping request to WorldSoft API: \n{}", requestXml);
            logger.info("📡 Headers: {}", headers);

            // 🚀 Send the request
            ResponseEntity<String> response = restTemplate.exchange(AIRSHOPPING_URL, HttpMethod.POST, entity, String.class);

            // ✅ Log response details
            logger.info("✅ Received response from WorldSoft API: \n{}", response.getBody());

            return response;
        } catch (Exception e) {
            logger.error("❌ Error communicating with WorldSoft API: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error processing request: " + e.getMessage());
        }
    }
}
