package com.springboot.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import java.util.List;

@Configuration
public class SecurityConfig {

    private final UserDetailsServiceImpl userDetailsService;
    private final JwtFilter jwtFilter;

    public SecurityConfig(UserDetailsServiceImpl userDetailsService, JwtFilter jwtFilter) {
        this.userDetailsService = userDetailsService;
        this.jwtFilter = jwtFilter;
        System.out.println("🚀 SecurityConfig Loaded!");
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        System.out.println("✅ AuthenticationManager Bean Loaded!");
        return authenticationConfiguration.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        System.out.println("✅ PasswordEncoder Bean Loaded!");
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        System.out.println("✅ SecurityFilterChain Configured!");

        return http
                .csrf(csrf -> csrf.disable()) // ✅ Disable CSRF for stateless API
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)) // ✅ Stateless for JWT
                .authorizeHttpRequests(auth -> auth
                        // ✅ Public Endpoints
                        .requestMatchers("/api/auth/**", "/api/users/register").permitAll()

                        // ✅ Make Flight Search Public (Fix for 403 Forbidden)
                        .requestMatchers("/api/flights/search").permitAll()

                        // ✅ Allow GET for /api/flights/** but require auth for POST/PUT/DELETE
                        .requestMatchers("/api/flights/**").authenticated()

                        // ✅ Require Authentication for Bookings
                        .requestMatchers("/api/bookings/create").authenticated()

                        // ✅ Require authentication for everything else
                        .anyRequest().authenticated()
                )
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class) // ✅ Add JWT filter
                .build();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder());
        System.out.println("✅ DaoAuthenticationProvider Loaded!");
        return authProvider;
    }

    @Bean
    public AuthenticationManager customAuthenticationManager() {
        System.out.println("✅ Custom AuthenticationManager Bean Loaded!");
        return new ProviderManager(List.of(authenticationProvider()));
    }
}
