package com.springboot.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "bookings")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "flight_id", nullable = false)
    private Flight flight;

    private String status; // Example: Pending, Confirmed, Canceled
    private BigDecimal totalPrice;

    public Booking(User user, Flight flight, String status, BigDecimal totalPrice) {
        this.user = user;
        this.flight = flight;
        this.status = status;
        this.totalPrice = totalPrice;
    }
}
