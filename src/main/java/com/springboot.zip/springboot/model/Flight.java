package com.springboot.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "flights")
public class Flight {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String airline;
    private String flightNumber;
    private String departure;
    private String destination;
    private String departureTime;
    private String arrivalTime;
    private String cabinClass;
    private String fareConditions;
    private String baggageAllowance;
    private BigDecimal price;

    public Flight(String airline, String flightNumber, String departure, String destination,
                  String departureTime, String arrivalTime, String cabinClass,
                  String fareConditions, String baggageAllowance, BigDecimal price) {
        this.airline = airline;
        this.flightNumber = flightNumber;
        this.departure = departure;
        this.destination = destination;
        this.departureTime = departureTime;
        this.arrivalTime = arrivalTime;
        this.cabinClass = cabinClass;
        this.fareConditions = fareConditions;
        this.baggageAllowance = baggageAllowance;
        this.price = price;
    }
}
