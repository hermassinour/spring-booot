package com.springboot.controller;

import com.springboot.service.FlightService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/flights")
public class FlightController {

    private static final Logger logger = LoggerFactory.getLogger(FlightController.class);
    private final FlightService flightService;

    // ✅ Constructor-based Dependency Injection
    public FlightController(FlightService flightService) {
        this.flightService = flightService;
    }

    // ✅ Search flights via WorldSoft API
    @GetMapping("/search")
    public ResponseEntity<String> searchFlights(
            @RequestParam String departure,
            @RequestParam String destination,
            @RequestParam String date) {
        logger.info("🔍 Searching flights from {} to {} on {}", departure, destination, date);
        return flightService.searchFlightsFromWorldSoft(departure, destination, date);
    }
}
