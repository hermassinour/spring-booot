package com.springboot.controller;

import com.springboot.dto.input.AirShoppingRequest;
import com.springboot.dto.input.OfferPriceRequest;
import com.springboot.dto.output.AirShoppingResponse;
import com.springboot.dto.output.OfferPriceResponse;
import com.springboot.service.NdcService;
import com.springboot.utils.DtoBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/ndc")
public class NdcController {

    @Autowired
    private NdcService ndcService;

    @Autowired
    private DtoBuilder dtoBuilder;

    @PostMapping(value = "/airshopping", consumes = "application/json", produces = "application/json")
    public ResponseEntity<AirShoppingResponse> airShopping(@RequestBody AirShoppingRequest input) {
        var rq = dtoBuilder.buildAirShoppingRQ(input);
        var rs = ndcService.callNdcEndpoint(rq);
        return ResponseEntity.ok(rs);
    }

    @PostMapping(value = "/offerprice", consumes = "application/json", produces = "application/json")
    public ResponseEntity<OfferPriceResponse> offerPrice(@RequestBody OfferPriceRequest input) {
        var rs = ndcService.handleOfferPrice(input);
        return ResponseEntity.ok(rs);
    }
}
