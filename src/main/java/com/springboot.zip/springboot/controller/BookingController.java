package com.springboot.controller;

import com.springboot.model.Booking;
import com.springboot.model.Flight;
import com.springboot.model.User;
import com.springboot.repository.BookingRepository;
import com.springboot.repository.FlightRepository;
import com.springboot.repository.UserRepository;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    private final BookingRepository bookingRepository;
    private final UserRepository userRepository;
    private final FlightRepository flightRepository;

    public BookingController(BookingRepository bookingRepository, UserRepository userRepository, FlightRepository flightRepository) {
        this.bookingRepository = bookingRepository;
        this.userRepository = userRepository;
        this.flightRepository = flightRepository;
    }

    // ✅ Create a new booking
    @PostMapping("/create")
    public ResponseEntity<Booking> createBooking(@RequestBody BookingRequest request) {
        // Extract the user and flight using the IDs from the request
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new RuntimeException("User with ID " + request.getUserId() + " not found"));

        Flight flight = flightRepository.findById(request.getFlightId())
                .orElseThrow(() -> new RuntimeException("Flight with ID " + request.getFlightId() + " not found"));

        // Check if user has already booked this flight
        boolean alreadyBooked = bookingRepository.findByUserId(request.getUserId())
                .stream()
                .anyMatch(booking -> booking.getFlight().getId().equals(request.getFlightId()));

        if (alreadyBooked) {
            return ResponseEntity.badRequest().body(null);
        }

        // Create a new booking
        Booking booking = new Booking(user, flight, "Pending", flight.getPrice());
        return ResponseEntity.ok(bookingRepository.save(booking));
    }

    // ✅ Get all bookings for a user
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Booking>> getUserBookings(@PathVariable Long userId) {
        List<Booking> bookings = bookingRepository.findByUserId(userId);
        if (bookings.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(bookings);
    }

    // Request body model
    @Setter
    @Getter
    public static class BookingRequest {
        // Getters and setters
        private Long userId;
        private Long flightId;

    }
}
