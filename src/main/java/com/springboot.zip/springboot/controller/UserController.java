package com.springboot.controller;

import com.springboot.dto.UserResponse;
import com.springboot.model.User;
import com.springboot.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "*") // ✅ Allows frontend access
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // ✅ Register a new user with password hashing
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@Valid @RequestBody User user) {
        System.out.println("🔍 Incoming Request: " + user);
        System.out.println("🔍 Received email: " + user.getEmail());
        System.out.println("🔍 Received password: " + user.getPassword());

        if (user.getPassword() == null || user.getPassword().trim().isEmpty()) {
            return ResponseEntity.badRequest().body("⚠️ Password cannot be empty");
        }

        User savedUser = userService.createUser(user);
        return ResponseEntity.ok(new UserResponse(savedUser.getId(), savedUser.getName(), savedUser.getEmail()));
    }

    // ✅ Custom error handler for validation failures
    @ExceptionHandler(org.springframework.web.bind.MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationExceptions(org.springframework.web.bind.MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error ->
                errors.put(error.getField(), error.getDefaultMessage()));

        return ResponseEntity.badRequest().body(errors);
    }

    // ✅ Get user by ID (safe response)
    @GetMapping("/{id}")
    public ResponseEntity<?> getUser(@PathVariable Long id) {
        try {
            User user = userService.getUserById(id);
            return ResponseEntity.ok(new UserResponse(user.getId(), user.getName(), user.getEmail()));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("❌ User not found: " + e.getMessage());
        }
    }
}
