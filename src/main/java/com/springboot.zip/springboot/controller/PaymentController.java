package com.springboot.controller;

import com.springboot.model.Booking;
import com.springboot.model.Payment;
import com.springboot.repository.BookingRepository;
import com.springboot.repository.PaymentRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentRepository paymentRepository;
    private final BookingRepository bookingRepository;

    public PaymentController(PaymentRepository paymentRepository, BookingRepository bookingRepository) {
        this.paymentRepository = paymentRepository;
        this.bookingRepository = bookingRepository;
    }

    // ✅ Process payment for a booking
    @PostMapping("/pay")
    public ResponseEntity<Payment> makePayment(
            @RequestParam Long bookingId,
            @RequestParam String paymentMethod,
            @RequestParam BigDecimal amount) {

        // Validate booking ID
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking with ID " + bookingId + " not found"));

        // Create a new payment record
        Payment payment = new Payment();
        payment.setBooking(booking);
        payment.setPaymentMethod(paymentMethod);
        payment.setPaymentStatus("Paid");
        payment.setAmount(amount);

        return ResponseEntity.ok(paymentRepository.save(payment));
    }
}
